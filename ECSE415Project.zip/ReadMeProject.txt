Our teams could not be merged for some reason, so we are: 
SuperCoolGroup as Sheng Hao Liu, sheng.h.liu@mail.mcgill.ca, 260585377
amakri1020 as Alexander Makrigiorgos, alexander.makrigiorgos@mail.mcgill.ca, 260573080


Our project is divided into 2 parts, one with a deep learning algorithm, another with an SVM. Our best results came from the SVM, so that is what we are officially submitting to be run on the private test data, however we are providing the code and instructions to run it to show all work done throughout the project.


The SVM:
To run ECSE415Project.ipynb,
1. have testingdescsift100.pkl and trainingdescsift100.pkl in the same folder
1.1 you should also have the Y_Train.csv file given to us in the same folder
2. run the first and second cell to have all imports and functions
3. run the 7th cell (the one with "Use this when dealing with SIFT/SURF")
4. wait until it says 1477 since that means all 1477 images were predicted
5. run the 9th cell (the one with "Save in results")
6. when it says Saving done! You can check the TestResults.csv file which will have all 1477 image results.

If there is any need to build your own .pkl files, then it is necessary to modify cells 5 and 6 by changing the function used in tempdesc = X(trainset2[allimg]) and the dump to the desired output file. 
Then it's just a matter of running all cells in sequence except you have to choose between cells 7/8 if you're using HoG or SIFT/SURF. 
All other cells below the saving cell were used for testing and running smaller scripts. 



The deep learning algorithm didn't yield very good results, but the code is given in CNN.py

To run CNN.py, the images must be split into data/train/cats and data/train/dogs, as well as data/validation/cats and data/validation/dogs for the validation set. Then simply run python CNN.py from the directory containing CNN.py and data/, and the neural net will begin training for the number of epochs specified in the file.

The saved keras models are called 30_epochs.h5 and 60_epochs.h5