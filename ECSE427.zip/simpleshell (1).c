/*
 * Assignment 1 
 * simpleshell.c
 * 
 * A "simple" C shell
 *
 *  Created on: Sep 28, 2016
 *  Due: Oct 16, 2016
 *      Author: Sheng Hao Liu
 */

// All includes
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <errno.h>
#include <stdbool.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// Global variables
#define MAX_LINE 	 20		// Assuming that I will not have more than 20 characters
#define HISTORY_SIZE 10		// Keep recent 10 commands in history
#define MAXJOBSIZE   10     // Allow 10 jobs to be run in bg
#define MAXJID    1<<10     // Allow max job ID to be 10 as well

// Job struct to store jobs as individual objects
struct job_t
{
    pid_t pid;
    int jid;
    char cmdline[MAX_LINE];
};

// History struct to store commands
struct his_t
{
	char cmdhist[MAX_LINE]; 
	int savedCmd;
};

// Variable definitions 
struct job_t jobs[MAXJOBSIZE]; 				  // job list of 10 in bg
struct his_t hist[HISTORY_SIZE];			  // history list of 10
struct his_t prin[HISTORY_SIZE];			  // duplicate list to print in the correct order
int nextjid = 0;               				  // id of the next job
int globalCommandCounter;      				  // counter for TOTAL commands, ranges from 0 to n
int jobCounter;                				  // counter for bg jobs
int histCounter;							  // counter for hist 0 - 9
int limit;									  // counter as global - 10
int parseInt;								  // everything after !
char *parseChar;							  // everything after !
bool request; 								  // if requesting a saved command
bool redirec;								  // for redirection
bool piping;								  // for piping
bool zerolength;							  // for length problem

// Method to exit the shell
void leaveShell()
{
    printf("Terminated shell session.\n");
    exit(0);
}

// Method to initialize the job list.
void initjobs(struct job_t *jobs)
{
    int i;
    
    for (i = 0; i < MAXJOBSIZE; i++)
    {
        jobs[i].pid = 0;
        jobs[i].jid = 0;
        jobs[i].cmdline[0] = '\0';
    }
}

// Method to initialize the job list.
void inithist(struct his_t *hist)
{
    int i;
    
    for (i = 0; i < HISTORY_SIZE; i++)
    {
        hist[i].cmdhist[0] = '\0';
        hist[i].savedCmd = 0;
    }
}

// Method to add job to the job list (struct list)
int addjob(struct job_t *jobs, pid_t pid, char *cmdline)
{
    int i;
    
    if (pid < 1)
        return 0;
    
    for (i = 0; i < MAXJOBSIZE; i++)
    {
        if (jobs[i].pid == 0)
        {
            jobs[i].pid = pid;
            jobs[i].jid = nextjid++;
            if (nextjid > MAXJOBSIZE)
                nextjid = 1;
            strcpy(jobs[i].cmdline, cmdline);
            return 1;
        }
    }
    return 0;
}

// Method to add a new command to the hist list
int addhist(struct his_t *hist, char *cmdhist)
{	
    strcpy(hist[histCounter].cmdhist, cmdhist);
    hist[histCounter].savedCmd = globalCommandCounter;
 
    return 0;
}

// Method to clear a job from job list. The method reshifts all the list up after cleaning.
void clearjob(int pidToClear)
{
    int targetJobIndex = 0;
    
    int i;
    
    for(i= 0; i < MAXJOBSIZE; i++)
    {
        if(jobs[i].pid == pidToClear)
        {
            targetJobIndex = jobs[i].jid;
            break;
        }
    }
    // shift the jobs list UP and delete the last entry
    
    int z;
    
    for(z = targetJobIndex; z<=jobCounter; z++)
    {
        jobs[targetJobIndex].pid = jobs[targetJobIndex + 1].pid;
        jobs[targetJobIndex].jid = jobs[targetJobIndex + 1].jid;
        strcpy(jobs[targetJobIndex].cmdline, jobs[targetJobIndex + 1].cmdline);
        
        if(z == targetJobIndex - 1)
        {
            break;
        }
    }
    
    jobCounter--;
    nextjid = jobCounter;
}

// Method to clean the list of history to print correctly after 10
void orderhist(struct his_t *hist)
{
	int tempcmd, i, j, k;
	char temphist[MAX_LINE];

	// set everything inside the buffer prin
	for(i = 0; i < 10; i++)
	{
		strcpy(prin[i].cmdhist, hist[i].cmdhist);
		prin[i].savedCmd = hist[i].savedCmd;
	}

	// check for saved commands
	for(j = 0; j < 10; j++)
	{
		for(k = j+1; k < 10; k++)
		{
			// if the "index" is more than the other
			if(prin[j].savedCmd > prin[k].savedCmd)
			{
				// swap the strings
				strcpy(temphist, prin[j].cmdhist);
				strcpy(prin[j].cmdhist, prin[k].cmdhist);
				strcpy(prin[k].cmdhist, temphist);
				// swap the ints
				tempcmd = prin[j].savedCmd;
				prin[j].savedCmd = prin[k].savedCmd;
				prin[k].savedCmd = tempcmd;
			}
		}
	}

}

// Method to find the command requested
void findhist(int cmdnumber, char *args[], char *reqarg[], struct his_t *hist)
{
	char reqcmd[20];
	int i, j;

	printf("Command number was: %d\n", cmdnumber); 

	if(globalCommandCounter < 10)
		for(i = 1; i < (globalCommandCounter + 1); i++)
		{
			//printf("%s\n", args[0]);
			if(cmdnumber == hist[i].savedCmd)	// I can find the command properly
			{
				strcpy(reqcmd, hist[i].cmdhist);
		        request = true;
			}
		}
	else
	{
		orderhist(hist); // returning a struct doesn't work properly, I made it a global
		for(j = 0; j < 10; j++) 
		{
			if(cmdnumber == prin[j].savedCmd)	// Even if it's > 10 I can find the command properly
			{
				strcpy(reqcmd, prin[j].cmdhist);
		        request = true;
			}
		}
	}

	printf("Command requested was: %s\n", reqcmd); // I can know what my command is

	// For some reason, I can get the command into the queue properly
	strcpy(reqarg[0], reqcmd);	// why does this not work? I can't place a command into the arguments queue?
	reqarg[1] = NULL;
}

// Method to list jobs. 
int listjobs(struct job_t *jobs)
{
    int temp_stat;
    
    int i;
    
    for(i = 0; i < jobCounter; i++)
    {
		// If a process was terminated, notifies about termination as well as removes the job from the list.
        if (waitpid(jobs[i].pid, &temp_stat, WNOHANG) != 0)
        {
            printf("Job %s with number with PID: %d ended and removed\n", jobs[i].cmdline, jobs[i].pid);
            clearjob(jobs[i].pid);
        }
        // Else displays job's pid and id.
        else
        {
            printf("[%d] (%d) ", jobs[i].jid, jobs[i].pid);
        }
    }
    
    return 0;
}

// Method to list the history, just prints the newered list
int listhist(struct his_t *hist)
{
	int i;
	int j;

	// 2 ways of printing the history list
	// if it's more than 10 global commands, we use the order
	// if it's less, we use the normal print
	if(globalCommandCounter < 10)
		for(i = 1; i < (globalCommandCounter + 1); i++)
		{
			printf("Command %d: %s \n", hist[i].savedCmd, hist[i].cmdhist);
		}
	else
	{
		orderhist(hist); // returning a struct doesn't work properly, I made it a global
		for(j = 0; j < 10; j++) 
		{
			printf("Command %d: %s \n", prin[j].savedCmd, prin[j].cmdhist);
		}
	}

	return 0;
}

// Method used for pwd.
void showPresentWorkingDirectory()
{
    char* cwd;
    
    char buff[PATH_MAX + 1];
    
    cwd = getcwd(buff, PATH_MAX +1);
    
    if( cwd != NULL ) {
        printf( "Current working directory is:  %s.\n", cwd );
    }
    else
    {
        printf("Could not determine current working directory!");
    }
}

// Method for cd.
void changeDirectory(char *args[])
{
    int changeResult = chdir(args[1]);
    
    if(changeResult != 0)
    {
        printf("Directory does not exist or was not found.");
    }
    else
    {
        printf("Now in : %s", args[1]);
    }
}

// Method for piping properly
void dopipe(char *newarg[], char *piparg[])  
{
    int pipefd[2];

    // get a pipe (buffer and fd pair) from the OS 
    if (pipe(pipefd)) 
    {
		perror("pipe");
		exit(127);
    }

    // the child process forks again to get the pipe working
    // let's mix it up with switches this time
    switch (fork()) {
    case -1:
        perror("fork");
        exit(127);
    case 0: // child process
        close(pipefd[0]);  // close the other side of the pipe 
        dup2(pipefd[1], 1);  // automatically closes previous fd 1 
        close(pipefd[1]);  // cleanup 
        
        // execute arguments before |
        execvp(newarg[0], newarg);

        // if something goes wrong
        perror("Uh oh, something went wrong ");
        exit(126);
    default: // parent process
        close(pipefd[1]);  // same as above but swapped
        dup2(pipefd[0], 0); 
        close(pipefd[0]);  
        
        // execute arguments after |
        execvp(piparg[0], piparg);

        // if something goes wrong
        perror("Uh oh, something went wrong ");
        exit(125);
    }
    // everything should be fully closed
}

// small changes to the getcmd function
int getcmd(char *prompt, char *args[], int *background)
{
	int length, i = 0;
	char *token, *loc;
	char *line = NULL;
	size_t linecap = 0;
	printf("%s", prompt);
	length = getline(&line, &linecap, stdin);

	// standard checks for entered commands
	if (length <= 0)
    {
        exit(-1); 
    }
    
    // this is supposed to work for nothing entered but it doesn't for some reason
    if (length == 1)
    {
        printf("Nothing was entered!\n");
        zerolength = true; // so here's a workaround
    }

	// Check if background is specified..
	if ((loc = index(line, '&')) != NULL) {
		*background = 1;
		*loc = ' ';
	} else
		*background = 0;

	while ((token = strsep(&line, " \t\n")) != NULL) {
		for (int j = 0; j < strlen(token); j++)
			if (token[j] <= 32)
				token[j] = '\0';
		if (strlen(token) > 0)
			args[i++] = token;
	}

	return i;
}

int main(void)
{
	// bunch of arrays for different purposes
	char *args[20];		// main arg
	char *newarg[20];	// for output redirect + piping
	char *piparg[20];	// for piping
	char *reqarg[20];	// for requesting a history command > does not work for some reason
	
	// multiple variables for different purposes
	int bg, status, err;
	int i, j, stop;
	int k, l, h;
	// initiation of variables
	jobCounter = 0;
    histCounter = 0;
    limit = 0;
    globalCommandCounter = 0;
 
    // initialize jobs buffer with job structs
    initjobs(jobs);

    // initialize history buffer with hist structs
    inithist(hist);

	while(1) {
		// vars before getting a command; we need to reset everything
		bg = 0; request = false; redirec = false; piping = false; zerolength = false;
        
        // clear all (note that we do not get to the 20th element)
        for(h = 0; h < 19; h++)
        {
            args[h] = NULL;
            newarg[h] = NULL;
            piparg[h] = NULL;
            reqarg[h] = NULL;
        }

		int cnt = getcmd("\n>> ", args, &bg); // cnt = count for commands?
		args[cnt] = NULL;	 


	if(zerolength == true) // workaround towards shell crashing due to nothing entered
	{
		printf("You need to enter something!\n" );
	}
	else
	{
		//----cases with commands:
	    // Case 1: if ! was entered and no commands have been entered previously
	    if( ((args[0][0] == '!') || strcmp(args[0], "history") == 0) && globalCommandCounter == 0)
	    {
	        printf("No command found in history.\n");
	    }
	    
	    // Case 2: if no ! was requested, simply add the current line to the buffer.
	    if((args[0][0] != '!') && strcmp(args[0], "history") !=0 && args[0] != NULL)
	    {
	        histCounter++;			// this counter is used for the hist struct
	        globalCommandCounter++;	// this is a global counter for commands

	        if (globalCommandCounter >= 10)
			{
				limit = (globalCommandCounter - 10); // i dont actually think i need limit
			}

			if (histCounter >= 10)
			{
				histCounter = 0; // i do need this though
			}

	        addhist(hist, *args); 
	    }
	    
	    // Case 3: if ! was requested, pull the command index with atoi and execute it.
	    if((args[0][0] == '!') && globalCommandCounter != 0)
	    {
	        parseChar = strtok(args[0], "!");
	        parseInt = atoi(parseChar);

	        //printf("%d\n", parseInt);

	        if(parseInt != 0 || parseInt >= globalCommandCounter)
	        {   
		        findhist(parseInt, args, reqarg, hist);	// it's inside of the function that doesn't work properly
		        //printf("%s\n", args[0]);
	        }
	    }

	    // Case 4: if history was requested, printout history of entered commands
	    if(strcmp(args[0], "history") == 0)
	    {
	        listhist(hist);
	    }
	    
	    // Case 5: if cd was requested with the specified directory
	    if(strcmp(args[0], "cd") == 0)
	    {
	        changeDirectory(args);
	    }
	    
	    // Case 6: if pwd was requested
	    if(strcmp(args[0], "pwd") == 0)
	    {
	        showPresentWorkingDirectory();
	    }
	    
	    // Case 7: if exit or quit was requested
	    if(strcmp(args[0], "exit") == 0 || strcmp(args[0], "quit") == 0)
	    {
	        leaveShell();
	    }
	    
	    // Case 8: if jobs was requested
	    if(strcmp(args[0], "jobs") == 0)
	    {
	        listjobs(jobs);
	    }
	    
	    // Case 9: if fg was requested
	    if (strcmp(args[0],"fg") == 0)
	    {
	        if(args[1] != NULL)
	        {
	        	waitpid(atoi(args[1]), &status, 0);
	        }
	        else
	        {
	            printf("NO PID WAS SPECIFIED, please input fg with a specified PID as an argument");
	        }
	    }

 		// Case 10: simple output redirection & piping
		if (args[0] != NULL && args[1] != NULL && args[2] != NULL) 
		// doing a very dumb check to see if there's more than 3 arguments
		// this will make it easier on the computer since it will not try to find > or | if we don't have anything
		{	
			for (i = 0; i < 20; i++)
			{	
				if(strcmp(args[i],">") == 0) // simple comparison
				{
					redirec = true;	
					stop = i;
					//printf("%d\n", stop);
					break;
				}
				if(strcmp(args[i],"|") == 0) // simple comparison
				{
					piping = true;
					stop = i;
					break;
				}
			}
			if(redirec == true)
			{
				for (j = 0; j < stop; j++) // simple truncation of args
				{
					newarg[j] = args[j];
				}
				newarg[cnt-(stop)] = NULL;
			}
			if(piping == true)
			{
				for (k = 0; k < stop; k++)
				{
					newarg[k] = args[k];
				}
				newarg[cnt-(stop)] = NULL;
				for (l = stop; l < (20-stop); l++)
				{
					piparg[l-(stop+1)] = args[l];
				}

			}
	    }

	    // check for all commands before forking
	    if((strcmp(args[0], "history") != 0 && strcmp(args[0], "cd") != 0 && strcmp(args[0], "pwd") != 0
            && strcmp(args[0], "jobs") != 0 && strcmp(args[0], "fg") != 0 && strcmp(args[0], "\n") != 0) 
            && args[0] != NULL)
        {	

		    if (bg)
	            printf("\nBackground enabled..\n");
	        else
	            printf("\nBackground not enabled \n");

			/* the steps can be..:
			(1) fork a child process using fork()
			(2) the child process will invoke execvp()
			(3) if background is not specified, the parent will wait,
			otherwise parent starts the next command... */

			pid_t cpid = fork();
			
			if(cpid < 0)
	        {
	            printf("Error. Did not fork a new process...\n");
	            exit(1);
	        }

			if(cpid == 0) // child process
	        {
	        	// have the fork invoke different args depending on what we want to do
	        	if(request == true)	// for a history request
	        	{
					if(execvp(reqarg[0], reqarg) < 0) // never gets to here because the function findhist doesn't work proper
		            {
		                printf("Error. execvp was not able to execute the command. \n");
		                exit(EXIT_FAILURE);
		            }
		            exit(0);
	        	}
	        	if(piping == true) // for a simple pipe
	        	{
	        		fflush(stdout); // make sure that the output is not filled (something might print)

	        		pid_t pipcpid = fork(); // we need to fork again since we need 2 total for piping to work

	        		if(pipcpid < 0)	
	        		{
			            printf("Error. Did not fork a new process...\n");
			            exit(1);
		        	}
		        	if(pipcpid == 0) // child child process
		        	{
		        		dopipe(newarg, piparg);
		        		exit(0);
		        	}
		        	else // child parent process
		        	{
		        		//printf("fork() returns child pid of %d\n", pipcpid);
				        pipcpid = wait(&status);
				        //printf("wait() returns child pid of %d\n", pipcpid);
				        printf("Pipe exit status was %d\n", status >> 8);
				        exit(0);
		        	}

	        	}
	        	if(redirec == true) // for a simple redirection
	        	{	
	        		// this is to make sure that everything gets into the output file
	        		int in = open(args[stop+1], O_RDWR|O_CREAT|O_TRUNC, 0600); // truncate for "new" file
	        		if (-1 == in) { perror("Error opening file"); return 255; }

					int out = open(args[stop+1], O_RDWR|O_CREAT|O_TRUNC, 0600); 
				    if (-1 == out) { perror("Error making an output"); return 255; }

				    int err = open(args[stop+1], O_RDWR|O_CREAT|O_TRUNC, 0600);
				    if (-1 == err) { perror("Error opening errorlog"); return 255; }

				    // get the fileno into an int
	        		int save_in = dup(fileno(stdin));
				    int save_out = dup(fileno(stdout));
    				int save_err = dup(fileno(stderr));
    				
    				// see if it can redirect properly
    				if (-1 == dup2(in, fileno(stdin))) { perror("cannot redirect stdin"); return 255; }
    				if (-1 == dup2(out, fileno(stdout))) { perror("cannot redirect stdout"); return 255; }
    				if (-1 == dup2(err, fileno(stderr))) { perror("cannot redirect stderr"); return 255; }

	        		// invoking execvp with command and arguments. If execvp fails, then returns and command was not executed.
		            if(execvp(newarg[0], newarg) < 0)
		            {
		                printf("Error. execvp was not able to execute the command. \n");
		                exit(EXIT_FAILURE);
		            }

		            // flush everything and close 
		            fflush(stdin); close(in);
					fflush(stdout); close(out);
				    fflush(stderr); close(err);

				    // get the stds 
		            dup2(save_in, fileno(stdin));
				    dup2(save_out, fileno(stdout));
				    dup2(save_err, fileno(stderr));

				    // close everything at the end 
		            close(save_in);
				    close(save_out);
				    close(save_err);

		            exit(0);
	        	}
	        	else // if we just want to run it normally
	        	{
	        		if(execvp(args[0], args) < 0)
		            {
		                printf("Error. execvp was not able to execute the command. \n");
		                exit(EXIT_FAILURE);
		            }
		            if(bg == 0)
		            	exit(0);
		            if(bg == 1)
		            	exit(2);
	        	}
	        }
	        else // parent
	        { 	
	            if(bg == 1)
	            {
	            	printf("Background process pid: %d\n", cpid);
	                // place jobs onto background if bg was specified
	                addjob(jobs, cpid, *args);
	                jobCounter++;
	            }       
	            else
	            {
	                waitpid(cpid, &status, 0);
	            }
	            
	            if ((WEXITSTATUS(status)==1))
	            {
	                printf("Child stopped, status = %d\n", WEXITSTATUS(status));
	            }

	        }
	    }
	}
	        
	}
}

